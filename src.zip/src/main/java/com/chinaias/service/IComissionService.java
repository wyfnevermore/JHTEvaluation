package com.chinaias.service;

import com.chinaias.entity.Commission;


public interface IComissionService{
	public String saveReturnID(Commission t);
	
	public String addCommission(Commission Commission);
}
