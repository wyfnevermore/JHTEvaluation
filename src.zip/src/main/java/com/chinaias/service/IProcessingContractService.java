package com.chinaias.service;

import java.util.List;

import com.chinaias.entity.jo.JoOrder;
import com.chinaias.entity.pc.PcCompInfo;
import com.chinaias.entity.pc.PcJobInfo;
import com.chinaias.entity.pc.PcOrder;
import com.chinaias.entity.pc.PcResourceInfo;

public interface IProcessingContractService {
	public List<PcOrder> generatePcOrder(List<JoOrder> joOrderList);
	public String contractInfoSave(PcJobInfo pcJobInfo,List<PcCompInfo> pcCompInfoList,List<PcResourceInfo> pcResourceInfoList);
}
