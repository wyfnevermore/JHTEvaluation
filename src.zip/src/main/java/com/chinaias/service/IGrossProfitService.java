package com.chinaias.service;

import java.util.List;

import com.chinaias.entity.GrossProfit;

public interface IGrossProfitService{
	public String saveReturnID(GrossProfit t);
	
	public String addGrossProfit(GrossProfit grossProfit);
	
	public List<GrossProfit> getGrossListByListid(String listID);
}
