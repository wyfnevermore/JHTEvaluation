package com.chinaias.service;

import com.chinaias.entity.QoHeader;

public interface IQoHeaderService extends IBaseService<QoHeader>{

}
