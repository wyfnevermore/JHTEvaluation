package com.chinaias.service;

import java.util.List;

import com.chinaias.entity.Transport;

public interface ITransportService  extends IBaseService<Transport>{

	public String saveReturnID(Transport transport);

	public String addTransport(Transport transport);
	
	public List<Transport> getTransportListByListid(String listID);
}
