package com.chinaias.service;

import com.chinaias.entity.QoLine;

public interface IQuatationOrderService {
	public QoLine setLegalEntityAndOther(QoLine qoLine); //set LegalEntiy OrderTyper PriceTable;
}
