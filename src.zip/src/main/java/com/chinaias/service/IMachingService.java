package com.chinaias.service;


public interface IMachingService{
	public boolean excelInsertContent(String excelPath,String excelHeadJosnStr,String excelMaterialJosnStr,String excelCompJosnStr,String excelHPJsonStr,String excelCartonJsonStr,String excelResultJsonStr);
	public boolean copyFile(String srcFileName, String destFileName, boolean overlay);
}
