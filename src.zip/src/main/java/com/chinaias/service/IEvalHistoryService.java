package com.chinaias.service;


import com.chinaias.entity.EvalHistory;

public interface IEvalHistoryService extends IBaseService<EvalHistory>{
	public boolean addEvalHistoryReID(EvalHistory evalHistory);
}
