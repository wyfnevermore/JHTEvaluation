package com.chinaias.entity.po;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="PARAMETER")
public class ERP_PO_PACKAGE {
	private G_PO_HEADERS g_PO_HEADERS;
	private G_PO_DISTRIBUTIONS g_PO_DISTRIBUTIONS;
	private G_PO_LINES g_PO_LINES;
	

	@XmlElement(name = "G_PO_HEADERS")
	public G_PO_HEADERS getG_PO_HEADERS() {
		return g_PO_HEADERS;
	}
	public void setG_PO_HEADERS(G_PO_HEADERS g_PO_HEADERS) {
		this.g_PO_HEADERS = g_PO_HEADERS;
	}
	
	@XmlElement(name = "G_PO_DISTRIBUTIONS")
	public G_PO_DISTRIBUTIONS getG_PO_DISTRIBUTIONS() {
		return g_PO_DISTRIBUTIONS;
	}
	public void setG_PO_DISTRIBUTIONS(G_PO_DISTRIBUTIONS g_PO_DISTRIBUTIONS) {
		this.g_PO_DISTRIBUTIONS = g_PO_DISTRIBUTIONS;
	}
	
	@XmlElement(name = "G_PO_LINES")
	public G_PO_LINES getG_PO_LINES() {
		return g_PO_LINES;
	}
	public void setG_PO_LINES(G_PO_LINES g_PO_LINES) {
		this.g_PO_LINES = g_PO_LINES;
	}
	
}
