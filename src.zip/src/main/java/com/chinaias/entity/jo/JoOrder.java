package com.chinaias.entity.jo;

import java.util.List;

public class JoOrder {
	private JoHeader joHeader;
	private List<JoLine> joLineList;
	public JoHeader getJoHeader() {
		return joHeader;
	}
	public void setJoHeader(JoHeader joHeader) {
		this.joHeader = joHeader;
	}
	public List<JoLine> getJoLineList() {
		return joLineList;
	}
	public void setJoLineList(List<JoLine> joLineList) {
		this.joLineList = joLineList;
	}
	
}
