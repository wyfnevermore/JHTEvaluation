package com.chinaias.entity.so;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="G_PROJECT_INFO")
public class G_PROJECT_INFO {
	private SoProject soProject;

	@XmlElement(name = "PROJECT")
	public SoProject getSoProject() {
		return soProject;
	}

	public void setSoProject(SoProject soProject) {
		this.soProject = soProject;
	}
	
	
}
