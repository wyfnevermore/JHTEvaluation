
package com.chinaias.webservice.erp;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>anonymous complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="P_IFACE_CODE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="P_BATCH_NUMBER" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="P_REQUEST_DATA" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "pifacecode",
    "pbatchnumber",
    "prequestdata"
})
@XmlRootElement(name = "InputParameters")
public class InputParameters {

    @XmlElementRef(name = "P_IFACE_CODE", namespace = "http://xmlns.oracle.com/apps/cux/soaprovider/plsql/cux_ws_server_factory_pkg/invokefmsws/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> pifacecode;
    @XmlElementRef(name = "P_BATCH_NUMBER", namespace = "http://xmlns.oracle.com/apps/cux/soaprovider/plsql/cux_ws_server_factory_pkg/invokefmsws/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> pbatchnumber;
    @XmlElementRef(name = "P_REQUEST_DATA", namespace = "http://xmlns.oracle.com/apps/cux/soaprovider/plsql/cux_ws_server_factory_pkg/invokefmsws/", type = JAXBElement.class, required = false)
    protected P_REQUEST_DATA prequestdata;

    /**
     * ��ȡpifacecode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPIFACECODE() {
        return pifacecode;
    }

    /**
     * ����pifacecode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPIFACECODE(JAXBElement<String> value) {
        this.pifacecode = value;
    }

    /**
     * ��ȡpbatchnumber���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPBATCHNUMBER() {
        return pbatchnumber;
    }

    /**
     * ����pbatchnumber���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPBATCHNUMBER(JAXBElement<String> value) {
        this.pbatchnumber = value;
    }

    /**
     * ��ȡprequestdata���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public P_REQUEST_DATA getPREQUESTDATA() {
        return prequestdata;
    }

    /**
     * ����prequestdata���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPREQUESTDATA(P_REQUEST_DATA value) {
        this.prequestdata = value;
    }

}
