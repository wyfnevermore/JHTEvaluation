
package com.chinaias.webservice.erp;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>anonymous complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="X_RETURN_CODE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="X_RETURN_MESG" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="X_RESPONSE_DATA" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "xreturncode",
    "xreturnmesg",
    "xresponsedata"
})
@XmlRootElement(name = "OutputParameters")
public class OutputParameters {

    @XmlElementRef(name = "X_RETURN_CODE", namespace = "http://xmlns.oracle.com/apps/cux/soaprovider/plsql/cux_ws_server_factory_pkg/invokefmsws/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> xreturncode;
    @XmlElementRef(name = "X_RETURN_MESG", namespace = "http://xmlns.oracle.com/apps/cux/soaprovider/plsql/cux_ws_server_factory_pkg/invokefmsws/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> xreturnmesg;
    @XmlElementRef(name = "X_RESPONSE_DATA", namespace = "http://xmlns.oracle.com/apps/cux/soaprovider/plsql/cux_ws_server_factory_pkg/invokefmsws/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> xresponsedata;

    /**
     * ��ȡxreturncode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getXRETURNCODE() {
        return xreturncode;
    }

    /**
     * ����xreturncode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setXRETURNCODE(JAXBElement<String> value) {
        this.xreturncode = value;
    }

    /**
     * ��ȡxreturnmesg���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getXRETURNMESG() {
        return xreturnmesg;
    }

    /**
     * ����xreturnmesg���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setXRETURNMESG(JAXBElement<String> value) {
        this.xreturnmesg = value;
    }

    /**
     * ��ȡxresponsedata���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getXRESPONSEDATA() {
        return xresponsedata;
    }

    /**
     * ����xresponsedata���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setXRESPONSEDATA(JAXBElement<String> value) {
        this.xresponsedata = value;
    }

}
