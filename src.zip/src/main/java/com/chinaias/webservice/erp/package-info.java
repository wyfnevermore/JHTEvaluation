//@javax.xml.bind.annotation.XmlSchema(namespace = "http://xmlns.oracle.com/apps/cux/soaprovider/plsql/cux_ws_server_factory_pkg/invokefmsws/", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
//@javax.xml.bind.annotation.XmlSchema(namespace = "http://xmlns.oracle.com/apps/cux/soaprovider/plsql/cux_ws_server_factory_pkg/invokefmsws/", xmlns = {@XmlNs(prefix = "", namespaceURI = "http://xmlns.oracle.com/apps/cux/soaprovider/plsql/cux_ws_server_factory_pkg/invokefmsws/")}, elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.chinaias.webservice.erp;

import javax.xml.bind.annotation.XmlNs;
