
package com.chinaias.webservice.erp;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>anonymous complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Responsibility" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="RespApplication" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="SecurityGroup" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="NLSLanguage" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Org_Id" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "responsibility",
    "respApplication",
    "securityGroup",
    "nlsLanguage",
    "orgId"
})
@XmlRootElement(name = "SOAHeader", namespace = "http://xmlns.oracle.com/apps/cux/soaprovider/plsql/cux_ws_server_factory_pkg/")
public class SOAHeader {

    @XmlElement(name = "Responsibility", namespace = "http://xmlns.oracle.com/apps/cux/soaprovider/plsql/cux_ws_server_factory_pkg/")
    protected String responsibility;
    @XmlElement(name = "RespApplication", namespace = "http://xmlns.oracle.com/apps/cux/soaprovider/plsql/cux_ws_server_factory_pkg/")
    protected String respApplication;
    @XmlElement(name = "SecurityGroup", namespace = "http://xmlns.oracle.com/apps/cux/soaprovider/plsql/cux_ws_server_factory_pkg/")
    protected String securityGroup;
    @XmlElement(name = "NLSLanguage", namespace = "http://xmlns.oracle.com/apps/cux/soaprovider/plsql/cux_ws_server_factory_pkg/")
    protected String nlsLanguage;
    @XmlElement(name = "Org_Id", namespace = "http://xmlns.oracle.com/apps/cux/soaprovider/plsql/cux_ws_server_factory_pkg/")
    protected String orgId;

    /**
     * ��ȡresponsibility���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResponsibility() {
        return responsibility;
    }

    /**
     * ����responsibility���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResponsibility(String value) {
        this.responsibility = value;
    }

    /**
     * ��ȡrespApplication���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRespApplication() {
        return respApplication;
    }

    /**
     * ����respApplication���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRespApplication(String value) {
        this.respApplication = value;
    }

    /**
     * ��ȡsecurityGroup���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSecurityGroup() {
        return securityGroup;
    }

    /**
     * ����securityGroup���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSecurityGroup(String value) {
        this.securityGroup = value;
    }

    /**
     * ��ȡnlsLanguage���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNLSLanguage() {
        return nlsLanguage;
    }

    /**
     * ����nlsLanguage���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNLSLanguage(String value) {
        this.nlsLanguage = value;
    }

    /**
     * ��ȡorgId���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrgId() {
        return orgId;
    }

    /**
     * ����orgId���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrgId(String value) {
        this.orgId = value;
    }

}
