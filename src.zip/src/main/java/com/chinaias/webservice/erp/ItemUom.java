package com.chinaias.webservice.erp;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;

public class ItemUom {
	private String IMPORT_ID;
	private String SOURCE_CODE;
	private String UOM_CLASS;
	private String UOM_CLASS_DESC;
	private String UOM_CODE;
	private String UOM_NAME;
	private String BASE_UOM_FLAG;
	private String SOURCE_HEADER_ID;
	private String SOURCE_LINE_ID;
	
	@XmlElement(name="IMPORT_ID")
	public String getIMPORT_ID() {
		return IMPORT_ID;
	}
	public void setIMPORT_ID(String iMPORT_ID) {
		IMPORT_ID = iMPORT_ID;
	}
	

	@XmlElement(name="SOURCE_CODE")
	public String getSOURCE_CODE() {
		return SOURCE_CODE;
	}
	public void setSOURCE_CODE(String sOURCE_CODE) {
		SOURCE_CODE = sOURCE_CODE;
	}
	

	@XmlElement(name="UOM_CLASS")
	public String getUOM_CLASS() {
		return UOM_CLASS;
	}
	public void setUOM_CLASS(String uOM_CLASS) {
		UOM_CLASS = uOM_CLASS;
	}
	

	@XmlElement(name="UOM_CLASS_DESC")
	public String getUOM_CLASS_DESC() {
		return UOM_CLASS_DESC;
	}
	public void setUOM_CLASS_DESC(String uOM_CLASS_DESC) {
		UOM_CLASS_DESC = uOM_CLASS_DESC;
	}
	

	@XmlElement(name="UOM_CODE")
	public String getUOM_CODE() {
		return UOM_CODE;
	}
	public void setUOM_CODE(String uOM_CODE) {
		UOM_CODE = uOM_CODE;
	}
	

	@XmlElement(name="UOM_NAME")
	public String getUOM_NAME() {
		return UOM_NAME;
	}
	public void setUOM_NAME(String uOM_NAME) {
		UOM_NAME = uOM_NAME;
	}
	

	@XmlElement(name="BASE_UOM_FLA")
	public String getBASE_UOM_FLAG() {
		return BASE_UOM_FLAG;
	}
	public void setBASE_UOM_FLAG(String bASE_UOM_FLAG) {
		BASE_UOM_FLAG = bASE_UOM_FLAG;
	}
	

	@XmlElement(name="SOURCE_HEADER_ID")
	public String getSOURCE_HEADER_ID() {
		return SOURCE_HEADER_ID;
	}
	public void setSOURCE_HEADER_ID(String sOURCE_HEADER_ID) {
		SOURCE_HEADER_ID = sOURCE_HEADER_ID;
	}
	

	@XmlElement(name="SOURCE_LINE_ID")
	public String getSOURCE_LINE_ID() {
		return SOURCE_LINE_ID;
	}
	public void setSOURCE_LINE_ID(String sOURCE_LINE_ID) {
		SOURCE_LINE_ID = sOURCE_LINE_ID;
	}
	
}
