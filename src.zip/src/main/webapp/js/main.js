$(document).ready(function(){
	var docWidth = $(document).width();
  var docHeight = $(document).height();
	var textWidth = $("#login_title").width(); 
  var logoWidth = $("#login_logo").width();
  $("#login_header").css("height",(docHeight*0.5));
  $("#login_header").css("margin-top",(0));
	//$("#login_title").css("margin-left",(docWidth-(43+logoWidth))/2-textWidth/2);


  var textHeight = $("#login_title").width();
  $("#right_Login_Alert").css("height",(docHeight*0.5));


  
  var rightAlertWidth = $("#right_Login_Alert").width();          
  angle.style.height = $("#right_Login_Alert").height()+"px";
  angle.style.width = $("#right_Login_Alert").width()+"px";

  
  

  var leftImgHeight = $("#login_img").height(); 
  $("#left_img").css("margin-top",((textHeight)/2)-(leftImgHeight/2));
  
});